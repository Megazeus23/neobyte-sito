﻿NeoByte Studios — press kit
https://neobytestudios.com/
Contatto per la stampa / Press contact: support@neobytestudios.com

=== ITALIANO ===

NEOBYTE STUDIOS
NeoByte Studios è uno studio indipendente italiano. Costruiamo videogiochi originali per telefono e PC, dalla prima idea al lancio.
Non inseguiamo le mode. Accendiamo mondi in cui vale la pena tornare.

SIGILLI DELL’ECLISSE
Libera sei città dal Velo dell’Eclisse con carte fantasy che evolvono.

Il Drago dell’Eclisse ha steso il suo Velo su sei città. La Guardiana ti aspetta al Ponte: raduna le tue carte e liberale, una a una.
Sotto il Velo le città si sono spente e chi le abitava ha dimenticato l’alba. I guardiani ora combattono per il Drago. Tocca a te riportare la luce.
Sigilli dell’Eclisse è un gioco di carte fantasy da collezionare: prepari la vittoria prima dello scontro, scegliendo le carte e il loro ordine, poi la battaglia va da sola.

Genere: Carte collezionabili, Fantasy, Strategia
Piattaforme: Android
Stato: In arrivo
Presto su Google Play
Pagina del gioco: https://neobytestudios.com/giochi/sigilli-dell-eclisse/

Questi materiali servono a parlare dei giochi di NeoByte Studios: articoli, video, recensioni. Per altri usi scrivici.

=== ENGLISH ===

NEOBYTE STUDIOS
NeoByte Studios is an independent Italian studio. We build original video games for mobile and PC, from the first idea to launch.
We do not chase trends. We light up worlds worth coming back to.

SIGILLI DELL’ECLISSE
Free six cities from the Veil of the Eclipse with fantasy cards that evolve.

The Eclipse Dragon has cast its Veil over six cities. The Guardian is waiting for you at the Bridge: gather your cards and free them, one by one.
Under the Veil the cities have gone dark, and those who lived there have forgotten the dawn. Their guardians now fight for the Dragon. It is up to you to bring back the light.
Sigilli dell’Eclisse is a collectible fantasy card game: you win before the clash, by choosing your cards and their order, then the battle plays out on its own.

Genre: Collectible cards, Fantasy, Strategy
Platforms: Android
Status: Coming soon
Soon on Google Play
Game page: https://neobytestudios.com/en/games/sigilli-dell-eclisse/

These materials are for talking about NeoByte Studios games: articles, videos, reviews. For other uses, write to us.
